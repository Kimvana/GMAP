r"""
Usage:

    GMAP Setup [target directory]
Copies GMAP\sourcefiles and GMAP\maps and places them in the target directory
under the names sourcefiles_copy and maps_copy.

The purpose of Setup is to simplify editing of these files.

Future functions may include a force flag and the abillity to create new
folders.

For more information, check the manual on N/A.
"""

# standard lib imports
import shutil
import sys
from pathlib import Path

# local imports
# from GMAP.src.tools.PrintTools import devprint as dpr
import GMAP.src.tools.Exceptions as GM_Ex
import GMAP.src.tools.FileHandler as GM_FH
import GMAP.src.tools.PrintTools as GM_PT


def Setup(callcommand):
    """Copies the maps and src dirs and copies them to a new map.

    Setup copies the maps folder and the src folder and copies them to
    a new folder that is specified by the user with an absolute path.
    src and maps will both go into the same folder.

    Parameters
    ----------
    callcommand : list of str
        This is the user input into the terminal.
    """

    printer = GM_PT.Printer
    printer.set_state("running", 2, 3)

    target = Path(callcommand[1]).resolve()

    target_srcdir = target / "sourcefiles_copy"
    target_mapdir = target / "maps_copy"

    verify_target(target, target_srcdir, target_mapdir)

    src_dir = GM_FH.FileLocations.sourcedir_hc
    map_dir = GM_FH.FileLocations.mapdir_hc

    shutil.copytree(src_dir, target_srcdir)
    shutil.copytree(map_dir, target_mapdir)

    printer.print(1, f"Copied folders to {target} successfully!")


def verify_target(target, target_srcdir, target_mapdir):
    """Verifies that it is possible to copy the folders to target.

    The target directory should exist and should not contain files named
    sourcefiles_copy or maps_copy. Then the GMAP\\sourcefiles directory
    and the GMAP\\maps directory will be copied into the target
    directory.

    Parameters
    ----------
    target : 'pathlib.Path'
        The object that is the path leading to the target folder.
    target_srcdir : 'pathlib.Path'
        The object that is the path that will be the location where the
        sourcefiles folder copy will reside.
    target_mapdir : 'pathlib.Path'
        The object that is the path that will be the location where the
        maps folder copy will reside.
    """

    if not target.is_dir():
        GM_PT.Printer.warning(
            f"{target} is not a valid directory. Please submit a valid target "
            "target directory.", "Setup_1", True,
            GMAPerrclass=GM_Ex.GmapNotADirectoryError
        )

    if Path(target_srcdir).exists():
        GM_PT.Printer.warning(
            f"The folder {target_srcdir} already exist. Please rename it or "
            "select another target folder.",
            "Setup_2", True,
            GMAPerrclass=GM_Ex.GmapIsADirectoryError
        )

    if Path(target_mapdir).exists():
        GM_PT.Printer.warning(
            f"The folder {target_mapdir} already exist. Please rename it or "
            "select another target folder.",
            "Setup_3", True,
            GMAPerrclass=GM_Ex.GmapIsADirectoryError
        )


def main():
    """Fakes behaviour as if called from __main__.

    During normal operation (user types 'GMAP ...' in the command line),
    this function should never be called. This function replicates the
    'normal' behaviour so partial tests are possible.
    """

    callcommand = sys.argv
    if len(callcommand) == 1:
        print(__doc__)
    else:
        GM_FH.FileLocations()
        Setup(callcommand)


if __name__ == "__main__":
    main()
